
#include "sobel.h"
#include<iostream>
using namespace std;
using namespace cv;

float sobel_x[3][3] =
    { { -1, 0, 1 },
      { -2, 0, 2 },
      { -1, 0, 1 } };

float sobel_y[3][3] =
    { { -1, -2, -1 },
      { 0,  0,  0 },
      { 1,  2,  1 } };

double magX = 0.0; // this is your magnitude

void sobel(const Mat& src, Mat& dst)
{
	// TODO
    
    int iWidth = src.rows;
    int iHeight = src.cols;
    int mag_x;
    int mag_y;
    uchar* pImg;
    uchar* pImg2;   
    pImg = (uchar*)src.ptr<uchar>();
    pImg2 = (uchar*)dst.ptr<uchar>();
    for (int x=1; x < iWidth-1; x++)
    {
        for (int y=1; y < iHeight-1; y++)
        {

            mag_x = (sobel_x[0][0] * pImg[iWidth * (y-1) + (x-1)])
                    + (sobel_x[0][1] * pImg[iWidth * (y-1) +  x   ])
                    + (sobel_x[0][2] * pImg[iWidth * (y-1) + (x+1)])
                    + (sobel_x[1][0] * pImg[iWidth *  y    + (x-1)])
                    + (sobel_x[1][1] * pImg[iWidth *  y    +  x   ])
                    + (sobel_x[1][2] * pImg[iWidth *  y    + (x+1)])
                    + (sobel_x[2][0] * pImg[iWidth * (y+1) + (x-1)])
                    + (sobel_x[2][1] * pImg[iWidth * (y+1) +  x   ])
                    + (sobel_x[2][2] * pImg[iWidth * (y+1) + (x+1)]);

            mag_y = (sobel_y[0][0] * pImg[iWidth * (y-1) + (x-1)])
                    + (sobel_y[0][1] * pImg[iWidth * (y-1) +  x   ])
                    + (sobel_y[0][2] * pImg[iWidth * (y-1) + (x+1)])
                    + (sobel_y[1][0] * pImg[iWidth *  y    + (x-1)])
                    + (sobel_y[1][1] * pImg[iWidth *  y    +  x   ])
                    + (sobel_y[1][2] * pImg[iWidth *  y    + (x+1)])
                    + (sobel_y[2][0] * pImg[iWidth * (y+1) + (x-1)])
                    + (sobel_y[2][1] * pImg[iWidth * (y+1) +  x   ])
                    + (sobel_y[2][2] * pImg[iWidth * (y+1) + (x+1)]);

            int val = (int)sqrt((mag_x * mag_x) + (mag_y * mag_y));

            if(val < 0) val = 0;
            if(val > 255) val = 255;

            pImg2[iHeight * y + x] = val;
        }
    }
}


void sobel_unroll(const Mat& src, Mat& dst)
{
	// TODO
    int iWidth = src.rows;
    int iHeight = src.cols;
    int mag_x0, mag_x1, mag_x2, mag_x3;
    int mag_y0, mag_y1, mag_y2, mag_y3;
    uchar* pImg;
    uchar* pImg2;   
    pImg = (uchar*)src.ptr<uchar>();
    pImg2 = (uchar*)dst.ptr<uchar>();
    for (int x=1; x < iWidth-1; x+=4)
    {
        for (int y=1; y < iHeight-1; y++)
        {

            mag_x0 = (sobel_x[0][0] * pImg[iWidth * (y-1) + (x-1)])
                    + (sobel_x[0][1] * pImg[iWidth * (y-1) + (x)  ])
                    + (sobel_x[0][2] * pImg[iWidth * (y-1) + (x+1)])
                    + (sobel_x[1][0] * pImg[iWidth * (y)   + (x-1)])
                    + (sobel_x[1][1] * pImg[iWidth * (y)   + (x)  ])
                    + (sobel_x[1][2] * pImg[iWidth * (y)   + (x+1)])
                    + (sobel_x[2][0] * pImg[iWidth * (y+1) + (x-1)])
                    + (sobel_x[2][1] * pImg[iWidth * (y+1) + (x)  ])
                    + (sobel_x[2][2] * pImg[iWidth * (y+1) + (x+1)]);
            mag_x1 = (sobel_x[0][0] * pImg[iWidth * (y-1) + (x-1) + 1])
                    + (sobel_x[0][1] * pImg[iWidth * (y-1) + (x)   + 1])
                    + (sobel_x[0][2] * pImg[iWidth * (y-1) + (x+1) + 1])
                    + (sobel_x[1][0] * pImg[iWidth * (y)   + (x-1) + 1])
                    + (sobel_x[1][1] * pImg[iWidth * (y)   + (x)   + 1])
                    + (sobel_x[1][2] * pImg[iWidth * (y)   + (x+1) + 1])
                    + (sobel_x[2][0] * pImg[iWidth * (y+1) + (x-1) + 1])
                    + (sobel_x[2][1] * pImg[iWidth * (y+1) + (x  ) + 1])
                    + (sobel_x[2][2] * pImg[iWidth * (y+1) + (x+1) + 1]);
            mag_x2 = (sobel_x[0][0] * pImg[iWidth * (y-1) + (x-1) + 2])
                    + (sobel_x[0][1] * pImg[iWidth * (y-1) + (x)   + 2])
                    + (sobel_x[0][2] * pImg[iWidth * (y-1) + (x+1) + 2])
                    + (sobel_x[1][0] * pImg[iWidth * (y)   + (x-1) + 2])
                    + (sobel_x[1][1] * pImg[iWidth * (y)   + (x)   + 2])
                    + (sobel_x[1][2] * pImg[iWidth * (y)   + (x+1) + 2])
                    + (sobel_x[2][0] * pImg[iWidth * (y+1) + (x-1) + 2])
                    + (sobel_x[2][1] * pImg[iWidth * (y+1) + (x)   + 2])
                    + (sobel_x[2][2] * pImg[iWidth * (y+1) + (x+1) + 2]);
            mag_x3 = (sobel_x[0][0] * pImg[iWidth * (y-1) + (x-1) + 3])
                    + (sobel_x[0][1] * pImg[iWidth * (y-1) + (x)   + 3])
                    + (sobel_x[0][2] * pImg[iWidth * (y-1) + (x+1) + 3])
                    + (sobel_x[1][0] * pImg[iWidth * (y)   + (x-1) + 3])
                    + (sobel_x[1][1] * pImg[iWidth * (y)   + (x)   + 3])
                    + (sobel_x[1][2] * pImg[iWidth * (y)   + (x+1) + 3])
                    + (sobel_x[2][0] * pImg[iWidth * (y+1) + (x-1) + 3])
                    + (sobel_x[2][1] * pImg[iWidth * (y+1) + (x)   + 3])
                    + (sobel_x[2][2] * pImg[iWidth * (y+1) + (x+1) + 3]);                                            
            mag_y0 = (sobel_y[0][0] * pImg[iWidth * (y-1) + (x-1)])
                    + (sobel_y[0][1] * pImg[iWidth * (y-1) + (x)  ])
                    + (sobel_y[0][2] * pImg[iWidth * (y-1) + (x+1)])
                    + (sobel_y[1][0] * pImg[iWidth * (y)   + (x-1)])
                    + (sobel_y[1][1] * pImg[iWidth * (y)   + (x)  ])
                    + (sobel_y[1][2] * pImg[iWidth * (y)   + (x+1)])
                    + (sobel_y[2][0] * pImg[iWidth * (y+1) + (x-1)])
                    + (sobel_y[2][1] * pImg[iWidth * (y+1) + (x)  ])
                    + (sobel_y[2][2] * pImg[iWidth * (y+1) + (x+1)]);           
            mag_y1 = (sobel_y[0][0] * pImg[iWidth * (y-1) + (x-1) + 1])
                    + (sobel_y[0][1] * pImg[iWidth * (y-1) + (x)   + 1])
                    + (sobel_y[0][2] * pImg[iWidth * (y-1) + (x+1) + 1])
                    + (sobel_y[1][0] * pImg[iWidth * (y)   + (x-1) + 1])
                    + (sobel_y[1][1] * pImg[iWidth * (y)   + (x)   + 1])
                    + (sobel_y[1][2] * pImg[iWidth * (y)   + (x+1) + 1])
                    + (sobel_y[2][0] * pImg[iWidth * (y+1) + (x-1) + 1])
                    + (sobel_y[2][1] * pImg[iWidth * (y+1) + (x)   + 1])
                    + (sobel_y[2][2] * pImg[iWidth * (y+1) + (x+1) + 1]);
            mag_y2 = (sobel_y[0][0] * pImg[iWidth * (y-1) + (x-1) + 2])
                    + (sobel_y[0][1] * pImg[iWidth * (y-1) + (x)   + 2])
                    + (sobel_y[0][2] * pImg[iWidth * (y-1) + (x+1) + 2])
                    + (sobel_y[1][0] * pImg[iWidth * (y)   + (x-1) + 2])
                    + (sobel_y[1][1] * pImg[iWidth * (y)   + (x)   + 2])
                    + (sobel_y[1][2] * pImg[iWidth * (y)   + (x+1) + 2])
                    + (sobel_y[2][0] * pImg[iWidth * (y+1) + (x-1) + 2])
                    + (sobel_y[2][1] * pImg[iWidth * (y+1) + (x  ) + 2])
                    + (sobel_y[2][2] * pImg[iWidth * (y+1) + (x+1) + 2]);
            mag_y3 = (sobel_y[0][0] * pImg[iWidth * (y-1) + (x-1) + 3])
                    + (sobel_y[0][1] * pImg[iWidth * (y-1) + (x)   + 3])
                    + (sobel_y[0][2] * pImg[iWidth * (y-1) + (x+1) + 3])
                    + (sobel_y[1][0] * pImg[iWidth * (y)   + (x-1) + 3])
                    + (sobel_y[1][1] * pImg[iWidth * (y)   + (x)   + 3])
                    + (sobel_y[1][2] * pImg[iWidth * (y)   + (x+1) + 3])
                    + (sobel_y[2][0] * pImg[iWidth * (y+1) + (x-1) + 3])
                    + (sobel_y[2][1] * pImg[iWidth * (y+1) + (x)   + 3])
                    + (sobel_y[2][2] * pImg[iWidth * (y+1) + (x+1) + 3]);
                                            
            int val0 = (int)sqrt((mag_x0 * mag_x0) + (mag_y0 * mag_y0));         
            int val1 = (int)sqrt((mag_x1 * mag_x1) + (mag_y1 * mag_y1));
            int val2 = (int)sqrt((mag_x2 * mag_x2) + (mag_y2 * mag_y2));
            int val3 = (int)sqrt((mag_x3 * mag_x3) + (mag_y3 * mag_y3));
                                            
            if(val0 < 0) val1 = 0;
            if(val0 > 255) val1 = 255;
            if(val1 < 0) val1 = 0;
            if(val1 > 255) val1 = 255;
            if(val2 < 0) val2 = 0;
            if(val2 > 255) val2 = 255;
            if(val3 < 0) val3 = 0;
            if(val3 > 255) val3 = 255;
            
            pImg2[iHeight * y + x] = val0;
            pImg2[iHeight * y + x + 1] = val1;
            pImg2[iHeight * y + x + 2] = val2;
            pImg2[iHeight * y + x + 3] = val3;                                            
        }
    }
}

void sobel_neon(const Mat& src, Mat& dst)
{/*
	// TODO

    // sobel_neon() code is commented out to allow remaining code to run // 

    int iWidth = src.rows;
    int iHeight = src.cols;
    uchar* pImg;
    uchar* pImg2;   
    pImg = (uchar*)src.ptr<uchar>();
    pImg2 = (uchar*)dst.ptr<uchar>();
    
    for (int x=1; x < iWidth-1; x+=16)
    {
        for (int y=1; y < iHeight-1; y++)
        {
            uint8x16_t mag_x = vmovq_n_u8(0);
            uint8x16_t mag_y = vmovq_n_u8(0);
            
            for(int x_sIdx = -1; x_sIdx <= 1; x_sIdx++){
                for(int y_sIdx = -1; y_sIdx <= 1; y_sIdx++){
                    uint8x16_t data_in_vec = vld1_u8(pImg + iWidth*(y + y_sIdx) + (x+x_sIdx));
                    uint8x16_t sobelx_vec = vmovq_n_u8(sobel_x[x_sIdx][y_sIdx]);
                    uint8x16_t sobely_vec = vmovq_n_u8(sobel_y[x_sIdx][y_sIdx]);
                    mag_x = vmlaq_f32(mag_x,sobelx_vec,data_in_vec);
                    mag_y = vmlaq_f32(mag_y,sobely_vec,data_in_vec);
                }
            }
         vst1q_f32(pImg2 + iWidth*y + x,accum)

*/}

