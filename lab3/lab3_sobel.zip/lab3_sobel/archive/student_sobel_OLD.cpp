
#include "sobel.h"
#include<iostream>
using namespace std;
using namespace cv;


float sobel_kernel_x[3][3] = {
	{ 1,  0, -1},
	{ 2,  0, -2},
	{ 1,  0, -1}};

float sobel_kernel_y[3][3] = {
	{ 1,  2, 1},
	{ 0,  0, 0},
	{ -1,  -2, -1}};

void sobel(const Mat& src, Mat& dst)
{
	// TODO
    const int HEIGHT = src.rows;
	const int WIDTH = src.cols;
    cout << "Height is " << HEIGHT << endl;
    cout << "Width is " << WIDTH << endl;
    cout << "sobel kernel_x 1st element: " << sobel_kernel_x[0][0] << endl;
    cout << "sobel kernel_x 2nd element: " << sobel_kernel_x[0][1] << endl;
    cout << "type of src image: " << typeid(src).name() << endl;
    cout << "num of channels in src image: " << src.channels() << endl;
    
    //set up pointers to access source and destination matrices
    uchar* src_ptr;
    uchar* dst_ptr;   
    src_ptr = (uchar*)src.ptr<uchar>();
    dst_ptr = (uchar*)dst.ptr<uchar>();
    
    //index through each pixel in src image
    for(int i = 1; i < HEIGHT-1; i++){
        for(int j = 1; j < WIDTH-1; j++){

            int mag_x, mag_y = 0;
            //cout << "src image pixel value: " << src_ptr[i*WIDTH + j] << endl;
            
            //index through sobel kernel elements
            for(int k_x = 0; k_x < 3; k_x++){
                for(int k_y = 0; k_y < 3; k_y++){
                    //accumulate products of 3x3 pixel neighborhood vals and kernel vals
                    //cout << "pixel [" << k_x << "][" << k_y << "] val: " << (float)src_ptr[(i+(k_x-1))*(WIDTH) + (j+(k_y-1))] << endl;
                    //mag_x += (int)src_ptr[(i+(k_x-1))*(WIDTH) + (j+(k_y-1))]*sobel_kernel_x[k_x][k_y];
                    //mag_y += (int)src_ptr[(i+(k_x-1))*(WIDTH) + (j+(k_y-1))]*sobel_kernel_y[k_x][k_y];
                    mag_x += src_ptr[(i+(k_x-1))*(WIDTH) + (j+(k_y-1))]*sobel_kernel_x[k_x][k_y];
                    mag_y += src_ptr[(i+(k_x-1))*(WIDTH) + (j+(k_y-1))]*sobel_kernel_y[k_x][k_y];
                }
            }
            //cout << "kernel loop iterated " << accum << " times" << endl; 
//            if(mag_squared < 0) mag_squared = 0;
//            if(mag_squared > 255) mag_squared = 255;
//            if((i == 50) && (j == 1))
//                {cout << "pixel " << (i*WIDTH + j) << " magnitude: " << mag_squared << endl; }
            dst_ptr[i*WIDTH + j] = mag_x;
            
            //dst_ptr[i*WIDTH + j] = src_ptr[i*WIDTH + j];
        }
    }
    
}


void sobel_unroll(const Mat& src, Mat& dst)
{
	// TODO
}

void sobel_neon(const Mat& src, Mat& dst)
{
	// TODO
}

