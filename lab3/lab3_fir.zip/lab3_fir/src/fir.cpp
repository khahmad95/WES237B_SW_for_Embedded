#include "main.h"

// ----------------------------------------------
// Run a FIR filter on the given input data
// ----------------------------------------------
void fir(float *coeffs, float *input, float *output, int length, int filterLength)
// ----------------------------------------------
{
    //TODO
    for (int n = 0; n < length - filterLength; n++){
        for (int k = 0; k < filterLength; k++){
            output[n] += input[n + k] * coeffs[k];
        }
    }
}

// ----------------------------------------------
// Run a FIR filter on the given input data using Loop Unrolling
// ----------------------------------------------
void fir_opt(float *coeffs, float *input, float *output, int length, int filterLength)
// ----------------------------------------------
{
    //TODO
    for (int n = 0; n < length - filterLength; n++){
        for (int k = 0; k < filterLength; k+=4){
            output[n] += input[n + k] * coeffs[k];
            output[n] += input[n + k + 1] * coeffs[k + 1];
            output[n] += input[n + k + 2] * coeffs[k + 2];
            output[n] += input[n + k + 3] * coeffs[k + 3];            
        }
    }
}

// ----------------------------------------------
// Run a FIR filter on the given input data using NEON
// ----------------------------------------------
void fir_neon(float *coeffs, float *input, float *output, int length, int filterLength)
// ----------------------------------------------
{
    //TODO
    //create input vector registers
    float32x4_t data_in;
    float32x4_t taps;
    
    //create output vector register 
    float32x4_t accum;
    //loop through input data
    for (int n = 0; n < length - filterLength; n++){
        //load input data
        data_in = vmovq_n_f32(input[n]);
        accum = vmovq_n_f32(0);
        //loop through filter coefficients; Vectorized
        for (int k = 0; k < filterLength; k+=4){
            //computation
            taps = vld1q_f32(coeffs+k);
            accum = vmlaq_f32(accum,taps,data_in);
        }    
        //store result
        vst1q_f32(output+n,accum);
    }
}


// ----------------------------------------------
// Create filter coefficients
// ----------------------------------------------
void designLPF(float* coeffs, int filterLength, float Fs, float Fx)
// ----------------------------------------------
{
	float lambda = M_PI * Fx / (Fs/2);

	for(int n = 0; n < filterLength; n++)
	{
		float mm = n - (filterLength - 1.0) / 2.0;
		if( mm == 0.0 ) coeffs[n] = lambda / M_PI;
		else coeffs[n] = sin( mm * lambda ) / (mm * M_PI);
	}
}
